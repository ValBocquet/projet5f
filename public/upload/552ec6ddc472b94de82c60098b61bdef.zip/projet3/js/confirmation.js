class Confirmation {
    constructor(element, timerId, cancelElt) {
        this.element = element;
        this.timerId = timerId;
        this.confirmation = document.getElementById(this.element);
        this.interval;
        this.cancelElt = cancelElt;
        // this.cancelBooking(this.cancelElt); 
      
        this.confirmBooking();
              
    }

    /**
     * Compte à rebours
     */
    startTimer() {
        
        let minutes = 20;
        let seconds = 0;
        if (sessionStorage.getItem("seconds") != null) {
            seconds = sessionStorage.getItem("seconds");
            minutes = sessionStorage.getItem("minutes");
        }
        this.interval = setInterval( () => {            
            seconds -= 1;
            if (minutes < 0) return;
            else if (seconds < 0 && minutes > 0) {
                minutes -= 1;
                seconds = 59;
            
            }
            sessionStorage.setItem("seconds", seconds);  
            sessionStorage.setItem("minutes", minutes);  

            if ((minutes === 0 && seconds ===0) || (sessionStorage.getItem('annulation') === 'true')) {
               this.resetTimer();
               document.location.reload(true); // recharger la page à la fin du chrono
            }
            var secondeText = seconds;
            var minuteText = minutes;
            if(seconds < 10) {
                secondeText = '0' + seconds;
            };
            if(minutes < 10) {
                minuteText = '0' + minutes;
            };
            document.getElementById(this.timerId).innerHTML = minuteText + ':' + secondeText ;

           
        
        }, 1000);
        sessionStorage.setItem("interval", this.interval);
    }

    /**
     * réinitialise le compteur
     */
    resetTimer() {
        clearInterval(this.interval);
        sessionStorage.clear();
    }

    /**
     * permet de confirmer une réservation
     */

    confirmBooking() {
        
        sessionStorage.setItem('annulation', 'false');
        this.startTimer();
        $('#adresse-validee').html(sessionStorage.getItem('adresse')); 
    
        this.confirmation.style.display = "block";
        let signaturePad = document.getElementById("signature-pad");
        signaturePad.style.visibility ="hidden";
        signaturePad.style.height = "0px";
    }


    cancelBooking() {
        $('#' + this.cancelElt).on('click', () => {
            clearInterval(this.interval);
            document.getElementById(this.timerId).innerHTML = '' ;
            this.confirmation.style.display = "none";
            document.getElementById("h1-reservation").innerHTML = "Réservation annulée";
            document.getElementById("h1-details").innerHTML = "";
        }
        
    )
        sessionStorage.clear();
};

    
} 