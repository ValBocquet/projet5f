$(function() {
    /** selectionne l'id carte pour lealeft */
    let $map = document.querySelector('#carte');

    const initMap = () => {
    let map = new Map();
    map.load($map);
    }

    if($map !== null) {
        initMap();
    }
    /** vérifications si une réservation est déjà en cours après un rechargement de page */
    if (sessionStorage.getItem('adresse')) {

        $('#confirmation' ).css('display', 'block');
        $('#adresse-validee').html(sessionStorage.getItem('adresse'));
        var address = sessionStorage.getItem("adresse");
        let canvasImg = sessionStorage.getItem('canvas');
        $('#canvas-img').attr("src", canvasImg);
        $('#canvas-img').css('display', 'block');
        $('#h1-details').text(localStorage.getItem('prenom') + ', voici votre réservation : ');
        let confirm = new Confirmation("confirmation", "timer", "annuler");

        $('#detail-station, p').css('margin', '8px');
        $('#alert').text('Réservation impossible');
        $('#form').css('display', 'none');
    } else {
        /** si pas de session, je vide ce qu'il peut y avoir d'enregistrer */
        sessionStorage.clear();
    }

    /** lorsque le bouton d'annulation est appuyé */
    $('#annuler').on('click', () => {
        sessionStorage.setItem('annulation', 'true');
        $('#confirmation').css('display', 'none');
    });

});

