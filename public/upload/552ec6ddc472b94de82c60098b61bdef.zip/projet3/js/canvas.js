class Canvas {
    constructor(element, saveElt, clearElt) {
        this.element = element; 
        this.saveElt = saveElt; 
        this.clearElt = clearElt; 

        let canvas = document.querySelector(element);
        this.ctx = canvas.getContext("2d");
        this.saveButton = document.getElementById(this.saveElt);
        this.clearButton = document.getElementById(this.clearElt);
    
        canvas.Width = 300;
        canvas.height = 86;
    
        this.ctx.strokeStyle = "#000";
        this.ctx.lineJoin = "round";
        this.ctx.lineCap = "round";
        this.ctx.lineWidth = 2;
        this.ctx.fillStyle = "#fff";
        this.ctx.fillRect(0, 0, canvas.width, canvas.height);
    
        this.isDrawing = false;
        this.drawEmpty = true;
        this.lastX = 0;
        this.lastY = 0;

        
        this.initDraw();
        this.effaceSignature();
        this.enregistreSignature();

    }


    /**
     * Dessine
     */
    draw(x, y) {
        if (!this.isDrawing) 
            return; // stop the fn from running when they are not moused down
        this.ctx.beginPath();
        // start from
        this.ctx.moveTo(this.lastX, this.lastY);
        // go to
        this.ctx.lineTo(x, y);
        this.ctx.stroke();
        [this.lastX, this.lastY] = [x, y];
        this.drawEmpty = false;
    }

    
    //Initialise le dessin
    initDraw() {
        
        canvas.addEventListener("mousedown", e => {
            this.isDrawing = true;
            [this.lastX, this.lastY] = [e.offsetX, e.offsetY];
        });
        canvas.addEventListener("touchstart", e => {
            if (e.touches && e.touches.length == 1) {
                this.isDrawing = true;
                let touch = e.touches[0];
                let touchX = touch.pageX - touch.target.offsetLeft;
                let touchY = touch.pageY - touch.target.offsetTop;
                [this.lastX, this.lastY] = [touchX, touchY];
                e.preventDefault();
            }
        });
    
        //Dessine
        canvas.addEventListener("mousemove", (e) => {
            this.draw(e.offsetX, e.offsetY);
        });
        canvas.addEventListener("touchmove", (e) => {
            if (e.touches && e.touches.length === 1) {
            let touch = e.touches[0];
            let touchX = touch.pageX - touch.target.offsetLeft;
            let touchY = touch.pageY - touch.target.offsetTop;
            this.draw(touchX, touchY);
            }
        });
        
        //Termine le dessin
        canvas.addEventListener("mouseup", () => {
            this.isDrawing = false;
        });
        canvas.addEventListener('mouseout', () => {
            this.isDrawing = false;
        });
        canvas.addEventListener("touchend", () => {
            this.isDrawing = false;
        });
    }

    
    /**
     * Fonction pour effacer la signature
     */
    effaceSignature() {
        this.clearButton.addEventListener("click", ()=> {
            this.ctx.clearRect(0, 0, canvas.width, canvas.height);
            this.drawEmpty = true;
        });
    }
    
    
    enregistreSignature() {
        this.saveButton.addEventListener("click", () => {
            if (this.drawEmpty !== true ) {
                
                // ENLEVER LE FOND NOIR
                $('#signature').fadeOut(1000);
                // maMap.markerClusters.clearLayers(maMap.marker);
                // maMap.addMarkers();

                // mise en session de l'adresse pour l'afficher une fois la réservation effectuée
                sessionStorage.setItem('adresse', $('#adresse span').html());
                let dataCanvas = canvas.toDataURL();
                let canvasImage = document.getElementById("canvas-img");
                
                canvasImage.src = dataCanvas;
                canvasImage.style.display = "block";
                $('#alert-signature').hide();
                $('#h1-reservation').css('display', 'block');
                $('#h1-reservation').html("Réservation confirmée");

                $('#h1-details').css('display', 'block');
                var name = sessionStorage.setItem('name', prenom.value.toUpperCase());
                $('#h1-details').html(prenom.value + ", votre réservation est valable pour 20 minutes.");
                
                /** appel de l'objet Confirmation */
                let confirmation = new Confirmation("confirmation", "timer", "annuler");
            
                /** mise en session du src de la signature canvas */
                sessionStorage.setItem("canvas", $('#canvas-img').attr('src'));
            } else {
                document.getElementById("alert-signature").style.display = "block";
                document.getElementById("h1-reservation").style.display = "none";
                document.getElementById("h1-details").style.display = "none";
            }
        });
        
    }

}






