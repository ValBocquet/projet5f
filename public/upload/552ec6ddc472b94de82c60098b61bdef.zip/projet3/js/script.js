
    // $('#img1').css('display', 'block');
    var img1 = document.getElementById('img1');
    img1.style['display'] = 'block';


class Slider {
    constructor() {
        this.interval 
        this.root = $('body')
        this.compteur = 1
        this.nextButton = $('.next')
        this.prevButton = $('.prev')
        this.pause = $('#pause')
        this.dot = $('.dot');
        

        this.prevButton.on('click', () => {
            this.prevSlider()
        })

        this.nextButton.on('click', () => {
            this.nextSlider()
        })

        this.pause.on('click', () => {
            this.stopTimer()
        })
        this.timer()

        this.clavier()

        this.dot.on('click', (e) => {
            this.dots(e)
        })
        
        this.generateDot()
    
    }

    
    
    timer() {
        this.interval = setInterval( () => {
            window.addEventListener('load', this.nextSlider())
        }, 5000);
        
    }
    stopTimer() {
        clearInterval(this.interval)
        $('#pause' ).css('display', 'none')
        $('#play' ).css('display', 'block')
    }
    prevSlider() {
        $('#img' +this.compteur).css('display', 'none');
        this.dot.removeClass('active');
        this.compteur--;
        if(this.compteur < 1) {
            this.compteur = 4;
            $('#img' +this.compteur).css('display', 'block');
            $('.dot-' +this.compteur).addClass('active');
        } else {
            $('#img' +this.compteur).css('display', 'block');
            $('.dot-' +this.compteur).addClass('active');
        }
    }

    nextSlider() {
        $('#img' +this.compteur).css('display', 'none');
        this.dot.removeClass('active');
        this.compteur++;
        if(this.compteur > 4) {
            this.compteur = 1;
            $('#img' +this.compteur).css('display', 'block');
            $('.dot-' +this.compteur).addClass('active');
        } else {
            $('#img' +this.compteur).css('display', 'block');
            $('.dot-' +this.compteur).addClass('active');
        }
    }
    clavier() {
        var _this = this;
        $('body').keydown(function(event) {
            console.log(this);
            console
            if(event.keyCode == 39) {
                _this.nextSlider();
            }
            else if(event.keyCode == 37) {
                _this.prevSlider();
            }
        });
   
    }
    dots(dotCurrent) {
        let dotClass = (dotCurrent.currentTarget.classList[2]);
        let className = dotClass.split('-') ;
        this.dot.removeClass('active');
        $('.dot-' +className[1]).addClass('active');
        $('#img' +this.compteur).css('display', 'none');
        this.compteur = className[1];
        $('#img' +className[1]).css('display', 'block');
    }

    generateDot() {
        
        this.dot.each(function(index) {
            $(this).addClass('dot-' + (index + 1));
        })
        $('.dot-1').addClass('active');
    }

   

}

new Slider()