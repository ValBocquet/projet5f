class Map {
    constructor(){
        this.mapTile = null;
        this.markers = [];
        this.markerClusters = new L.MarkerClusterGroup(); // initialisation du groupe de clusters
        this.APIUrl = "https://api.jcdecaux.com/vls/v1/stations?contract=lyon&apiKey=3aa8035c5c634062174618c01d8ffafe323638f2";
        this.iconGreen = L.icon({
            iconUrl: 'img/green.svg',
            iconSize: [45, 45], 
            iconAnchor: [22, 50],
            className : 'markerActive'
        })
        this.iconRed = L.icon({
            iconUrl: 'img/red.svg',
            iconSize: [45, 45], 
            iconAnchor: [22, 50],
            className : 'markerInactive'
        })
    }

    /**
     * Charge la carte depuis OpenStreetMap de façon asynchrone et l'ajoute sur this.map
     * @param {HTMLElement} element 
     */
    load(element) {
        this.mapTile = L.map(element).setView([45.75, 4.82], 13);
        L.tileLayer('https://{s}.tile.openstreetmap.fr/osmfr/{z}/{x}/{y}.png', {
            attribution: 'données © <a href="//osm.org/copyright">OpenStreetMap</a>/ODbL - rendu <a href="//openstreetmap.fr">OSM France</a>'
        }).addTo(this.mapTile);
        this.addMarkers();
    }

    /**
     * Charge les stations, applique l'icône vert ou rouge en fonction du statut et du nombre de vélos 
     */
    addMarkers() {
        this.ajax = new Ajax(this.APIUrl);
        this.ajax.ajaxGet(this.APIUrl, (stations) => {
        stations.forEach((station) => {
            if (station.status === "OPEN" && station.available_bikes > 0) {
                let marker = L.marker([station.position.lat, station.position.lng]).setIcon(this.iconGreen);
                this.markers.push(marker);   

                
                this.markerClusters.addLayer(marker); 
                //Gestion de l'affichage des détails au clic sur le marqueur
                marker.addEventListener('click', (e) => {
                    this.booking = new Booking("alert", "form", "adresse", "velos-disponibles", "places-disponibles", station, "valide-nom");
                        this.booking.fillUpNames("prenom", "nom");
                        this.booking.authorizeBooking();
                        this.booking.showSignaturePad("prenom", "nom", "signature-pad", "canvas", "alert-nom");
                    if(sessionStorage.getItem('adresse') !== null) {
                        $('#alert').text('Réservation non disponible');
                        $('#form').hide();
                    };

                    
                    
                })   
            } else {
                /** si condition non respectée, affichage des stations en rouge */
                let marker = L.marker([station.position.lat, station.position.lng]).setIcon(this.iconRed);
                /** ajout des markers */
                this.markers.push(marker);
                /** regroupement des markers dans les Clusters */
                this.markerClusters.addLayer(marker); 
                //Gestion de l'affichage des détails au clic sur le marqueur
                marker.addEventListener('click', (e) => {
                    /** nouvelle réservation en cours, création d'un objet Booking (block) */
                    this.booking = new Booking("alert", "form", "adresse", "velos-disponibles", "places-disponibles", station);
                    this.booking.blockBooking();
                })  
            }
            

        })
        this.mapTile.addLayer(this.markerClusters);
        })
    
    }
    /**
     * Gère l'évenement au clic sur la station
     * @param {event} event 
     * @param {Function} cb 
     */
    addEventListener (event, cb) {
        this.popup.addEventListener('add', () => {
            this.popup.addEventListener(event, cb);
        })
    }
    
}
$(function() {
    const maMap = new Map();
});