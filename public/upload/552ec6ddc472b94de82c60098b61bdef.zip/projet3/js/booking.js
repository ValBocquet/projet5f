class Booking {
    constructor(alertElt, formElt, addressElt, bikesElt, standsElt, stationInfos, validationButton) {
        this.alertElt = alertElt;
        this.formElt = formElt;
        this.addressElt = addressElt;
        this.standsElt = standsElt;
        this.bikesElt = bikesElt;
        this.stationInfos = stationInfos;
        this.validationButton = validationButton;
    }


    /**
     * Mise en localstorage du nom et prénom, pour les garder en mémoire même après fermeture navigateur
     * @param {String} firstNameField
     * @param {String} lastNameField
     */
    fillUpNames(firstNameField, lastNameField) {
        let firstNameRegistered = localStorage.getItem('prenom');
        let lastNameRegistered = localStorage.getItem('nom');
        if (localStorage.getItem('prenom') && localStorage.getItem('nom')) {
            $('#prenom').val(localStorage.getItem('prenom'));
            $('#nom').val(localStorage.getItem('nom'));
        }


    }
    /**
     * Affiche les détails de la station et le formulaire de réservation
     */
    authorizeBooking() {
        let nombreVelos = this.stationInfos.available_bikes;
        document.getElementById(this.alertElt).innerHTML = '<div> Réservation possible </div>';
        document.getElementById(this.addressElt).innerHTML = "Retrouvez votre vélo à l'adresse suivante : " + "<span>" + this.stationInfos.address + "</span>";
        document.getElementById(this.standsElt).innerHTML = "Places disponibles : " + this.stationInfos.available_bike_stands;
        if (this.stationInfos.address === sessionStorage.getItem('adresse')) {
            nombreVelos = nombreVelos - 1;
        } else {
            document.getElementById(this.formElt).style.display = 'block';
        }
        document.getElementById(this.bikesElt).innerHTML = "Vélos disponibles : " + nombreVelos;
    }

    /**
     * Affiche une alerte indiquant que la station est fermée
     */
    blockBooking() {
        document.getElementById(this.alertElt).innerHTML = '<div> Réservation non disponible </div>';
        document.getElementById(this.addressElt).innerHTML = "Retrouvez votre vélo à l'adresse suivante : " + this.stationInfos.address;
        document.getElementById(this.standsElt).innerHTML = "Places disponibles : " + this.stationInfos.available_bike_stands;
        document.getElementById(this.bikesElt).innerHTML = "Vélos disponibles : " + this.stationInfos.available_bikes;
        document.getElementById(this.formElt).style.display = "none";


    }



    /**
     * Affiche le canvas de signature si le formulaire est correctement complété
     * @param {String} firstNameField 
     * @param {String} lastNameField
     * @param {String} nameField 
     * @param {String} signatureField 
     * @param {String} canvasField 
     * @param {String} validationBtn 
     */
    showSignaturePad(firstNameField, lastNameField, signatureField, canvasField, alertNom) {
        document.getElementById(this.validationButton).addEventListener("click", function (e) {
            var prenom = $('#prenom').val();
            var nom = $('#nom').val();


            localStorage.setItem("nom", nom);
            localStorage.setItem("prenom", prenom);
            // let signaturePad = document.getElementById(signatureField);
            let canvas = new Canvas(canvasField, "valide-signature", "efface-signature");

/** Expression régulière pour vérifier la véracité du nom et prénom + gestion des espaces blancs */
            if ((/^[a-zA-Z\-\W]+$/.test(prenom)) && (/^[a-zA-Z\-\W]+$/.test(nom)) && (prenom.trim() !== '' && nom.trim() !== '')) {

                $('#signature').css('display', 'block');

                canvas.initDraw();
                canvas.effaceSignature();
                canvas.enregistreSignature();
                $('#' + alertNom).hide();
                document.getElementById("h1-reservation").innerHTML = "Votre réservation";
                document.getElementById("h1-details").innerHTML = "Une fois validée, vout trouverez les détails de votre réservation dans le footer ci-dessous.";
            } else {
                document.getElementById(alertNom).style.display = "block";
            }
        });

    }

}
$(function () {
    $('.fas.fa-times').on('click', function () {
        $('#signature').fadeOut(1000);
    });
});